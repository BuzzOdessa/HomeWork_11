﻿namespace Animals.Core.Common;

public interface IAggregateRoot
{
}
